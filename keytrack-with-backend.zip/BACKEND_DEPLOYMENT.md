# KeyTrack 后端部署指南

## 项目概述

这是 KeyTrack 视频标注工具的完整后端实现，使用 **FastAPI + SQLite** 实现数据持久化存储。所有数据（视频、关键帧、标签分组、应用状态）都将保存到服务器数据库，而不是浏览器本地存储。

### 核心改进

| 功能 | 原版（localStorage） | 新版（后端） |
|------|-------------------|----------|
| **数据持久性** | 浏览器清缓存即丢失 | 服务器持久化存储 |
| **多设备同步** | 不支持 | 支持（同一后端） |
| **数据安全** | 无备份机制 | 支持导入/导出 |
| **存储空间** | 受浏览器限制（5-10MB） | 无限制 |

---

## 架构设计

```
┌─────────────────────────────────────────────────────┐
│                   浏览器 (React)                     │
│  ┌───────────────────────────────────────────────┐  │
│  │ App.tsx (useAppData Hook)                     │  │
│  │ - 管理视频、关键帧、标签分组状态               │  │
│  │ - 自动同步到后端 API                          │  │
│  └───────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
                        ↓ HTTP
┌─────────────────────────────────────────────────────┐
│              后端 (FastAPI + SQLite)                 │
│  ┌───────────────────────────────────────────────┐  │
│  │ /api/videos         - 视频 CRUD               │  │
│  │ /api/keyframes      - 关键帧 CRUD             │  │
│  │ /api/groups         - 标签分组 CRUD           │  │
│  │ /api/app-state      - 应用状态管理            │  │
│  │ /api/backup/*       - 数据导入/导出           │  │
│  │ /api/stats          - 统计信息                │  │
│  └───────────────────────────────────────────────┘  │
│                      ↓                               │
│  ┌───────────────────────────────────────────────┐  │
│  │ SQLite 数据库 (backend/data/keytrack.db)      │  │
│  │ - videos 表                                   │  │
│  │ - keyframes 表                                │  │
│  │ - groups 表                                   │  │
│  │ - app_state 表                                │  │
│  └───────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

---

## 快速开始

### 方式一：一键启动脚本（推荐）

#### Windows PowerShell

```powershell
# 进入项目目录
cd E:\keytrack-with-backend

# 运行启动脚本
.\start.ps1
```

脚本会自动：
1. 启动后端服务（端口 8000）
2. 启动前端应用（端口 3000）
3. 打开浏览器访问应用

#### macOS/Linux

```bash
cd /path/to/keytrack-with-backend
bash start.sh
```

---

### 方式二：手动启动

#### 第一步：启动后端

```bash
# Windows (CMD)
cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8000

# macOS/Linux
cd backend
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000
```

启动成功输出：
```
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000
```

#### 第二步：启动前端（新终端窗口）

```bash
# Windows (CMD)
npm install
npm run dev

# macOS/Linux
npm install
npm run dev
```

启动成功输出：
```
➜  Local:   http://localhost:3000/
```

#### 第三步：打开浏览器

访问 `http://localhost:3000`

---

## 后端 API 文档

### 基础信息

- **基础 URL**：`http://localhost:8000/api`
- **交互式文档**：`http://localhost:8000/docs`（Swagger UI）
- **ReDoc 文档**：`http://localhost:8000/redoc`

### 核心接口

#### 1. 视频管理

```
GET    /videos              # 获取所有视频
POST   /videos              # 创建视频
GET    /videos/{id}         # 获取单个视频
PUT    /videos/{id}         # 更新视频
DELETE /videos/{id}         # 删除视频
```

**创建视频示例：**
```bash
curl -X POST http://localhost:8000/api/videos \
  -H "Content-Type: application/json" \
  -d '{
    "title": "My Video",
    "url": "https://example.com/video.mp4",
    "type": "url",
    "last_accessed": 1678830000000
  }'
```

#### 2. 关键帧管理

```
GET    /keyframes              # 获取所有关键帧
POST   /keyframes              # 创建关键帧
GET    /keyframes/{id}         # 获取单个关键帧
PUT    /keyframes/{id}         # 更新关键帧
DELETE /keyframes/{id}         # 删除关键帧
```

**创建关键帧示例：**
```bash
curl -X POST http://localhost:8000/api/keyframes \
  -H "Content-Type: application/json" \
  -d '{
    "video_id": "video-123",
    "time": 10.5,
    "note": "Important moment",
    "group_id": "group-456",
    "created_at": 1678830000000
  }'
```

#### 3. 标签分组管理

```
GET    /groups              # 获取所有分组
POST   /groups              # 创建分组
GET    /groups/{id}         # 获取单个分组
PUT    /groups/{id}         # 更新分组
DELETE /groups/{id}         # 删除分组
```

#### 4. 应用状态

```
GET    /app-state           # 获取应用状态
PUT    /app-state           # 更新应用状态
```

#### 5. 数据备份/恢复

```
GET    /backup/all          # 导出所有数据（JSON）
POST   /backup/restore      # 导入数据
DELETE /backup/clear        # 清空所有数据
```

#### 6. 统计信息

```
GET    /stats               # 获取统计数据
GET    /health              # 健康检查
```

---

## 数据库结构

### videos 表
```sql
CREATE TABLE videos (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    type TEXT DEFAULT 'url',  -- 'file' 或 'url'
    last_accessed INTEGER NOT NULL
);
```

### keyframes 表
```sql
CREATE TABLE keyframes (
    id TEXT PRIMARY KEY,
    video_id TEXT NOT NULL,
    time FLOAT NOT NULL,
    note TEXT,
    group_id TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
```

### groups 表
```sql
CREATE TABLE groups (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    color TEXT NOT NULL  -- 十六进制颜色
);
```

### app_state 表
```sql
CREATE TABLE app_state (
    id INTEGER PRIMARY KEY DEFAULT 1,
    current_video_id TEXT,
    sidebar_open INTEGER DEFAULT 1,
    theater_mode INTEGER DEFAULT 0,
    playback_speed FLOAT DEFAULT 1.0,
    video_zoom FLOAT DEFAULT 1.0
);
```

---

## 前端集成

### 1. storageService.ts

新增的服务层提供了与后端 API 的通信接口：

```typescript
import { videoService, keyframeService, groupService, appStateService } from './storageService';

// 获取所有视频
const videos = await videoService.getAll();

// 创建视频
const newVideo = await videoService.create({
  title: 'My Video',
  url: 'https://example.com/video.mp4',
  type: 'url',
  last_accessed: Date.now()
});

// 更新视频
await videoService.update(videoId, { title: 'Updated Title' });

// 删除视频
await videoService.delete(videoId);
```

### 2. useAppData Hook

自定义 Hook 简化了数据管理：

```typescript
import { useAppData } from './useAppData';

export default function App() {
  const {
    data,
    addVideo,
    updateVideo,
    deleteVideo,
    addKeyframe,
    updateKeyframe,
    deleteKeyframe,
    addGroup,
    updateGroup,
    deleteGroup,
    saveAppState
  } = useAppData();

  // 使用数据
  const { videos, keyframes, groups } = data;
}
```

### 3. Vite 代理配置

`vite.config.ts` 已配置 API 代理：

```typescript
server: {
  proxy: {
    '/api': {
      target: 'http://localhost:8000',
      changeOrigin: true,
      rewrite: (path) => path,
    },
  },
}
```

---

## 数据持久化与备份

### 自动备份

数据自动保存到 `backend/data/keytrack.db` SQLite 数据库文件。

### 手动导出

```bash
# 导出所有数据为 JSON
curl http://localhost:8000/api/backup/all > backup.json
```

### 手动导入

```bash
curl -X POST http://localhost:8000/api/backup/restore \
  -H "Content-Type: application/json" \
  -d @backup.json
```

### 云盘同步（可选）

将 `backend/data/` 目录放入 OneDrive/Google Drive/百度网盘同步目录，实现自动云备份：

```bash
# 修改 backend/models.py 中的 DATA_DIR 路径
DATA_DIR = Path(r"C:\Users\用户名\OneDrive\keytrack-data")
```

---

## 常见问题

### Q1: 后端启动失败，提示 "Address already in use"

**解决**：8000 端口被占用，改用其他端口：
```bash
python -m uvicorn main:app --host 0.0.0.0 --port 8001
```
同时修改 `vite.config.ts` 中的 proxy target 端口。

### Q2: 前端无法连接后端，提示 "ECONNREFUSED"

**解决**：确保后端服务正在运行：
```bash
curl http://localhost:8000/api/health
```

### Q3: 数据丢失了怎么办？

**解决**：从备份恢复：
```bash
curl -X POST http://localhost:8000/api/backup/restore \
  -H "Content-Type: application/json" \
  -d @backup.json
```

### Q4: 如何在多台电脑上共享数据？

**解决**：部署后端到云服务器（如 Railway、Render、Heroku），前端连接到云端后端：

```typescript
// storageService.ts
const API_BASE = 'https://your-backend-url.com/api';
```

### Q5: 如何重置所有数据？

**解决**：清空数据库：
```bash
curl -X DELETE http://localhost:8000/api/backup/clear
```

---

## 生产部署

### 部署到 Railway

1. 在 Railway 创建新项目
2. 连接 GitHub 仓库
3. 配置环境变量（如需）
4. 部署后端

### 部署到 Render

1. 创建新 Web Service
2. 选择 Python 环境
3. 设置启动命令：`uvicorn main:app --host 0.0.0.0 --port $PORT`
4. 部署

### 前端连接云端后端

修改 `storageService.ts`：

```typescript
const API_BASE = process.env.VITE_API_URL || '/api';
```

在 `.env` 中配置：

```
VITE_API_URL=https://your-backend-url.com/api
```

---

## 文件结构

```
keytrack-with-backend/
├── backend/
│   ├── main.py              # FastAPI 主应用
│   ├── models.py            # SQLAlchemy 数据库模型
│   ├── schemas.py           # Pydantic 数据验证
│   ├── requirements.txt      # Python 依赖
│   ├── test_api.py          # API 测试脚本
│   ├── data/
│   │   ├── keytrack.db      # SQLite 数据库
│   │   └── uploads/         # 文件上传目录
│   └── server.log           # 服务日志
├── src/
│   ├── App.tsx              # React 主应用
│   ├── types.ts             # TypeScript 类型定义
│   ├── storageService.ts    # API 通信层
│   └── useAppData.ts        # 数据管理 Hook
├── vite.config.ts           # Vite 配置（含 API 代理）
├── package.json             # 前端依赖
├── start.ps1                # PowerShell 启动脚本
├── start.sh                 # Bash 启动脚本
└── BACKEND_DEPLOYMENT.md    # 本文件
```

---

## 技术栈

| 层 | 技术 | 版本 |
|----|------|------|
| **前端** | React | 19.x |
| **前端构建** | Vite | 7.x |
| **后端** | FastAPI | 0.104.x |
| **后端服务器** | Uvicorn | 0.24.x |
| **数据库** | SQLite | 3.x |
| **ORM** | SQLAlchemy | 2.0.x |
| **数据验证** | Pydantic | 2.5.x |

---

## 支持与反馈

如遇到问题，请：

1. 查看 `backend/server.log` 后端日志
2. 检查浏览器控制台（F12）前端错误
3. 运行 `backend/test_api.py` 验证 API 可用性
4. 访问 `http://localhost:8000/docs` 查看 API 文档

---

**最后更新**：2026-05-15  
**版本**：1.0.0
