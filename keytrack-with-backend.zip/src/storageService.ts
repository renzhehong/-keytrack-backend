/**
 * 存储服务 - 对接后端 API
 * 将所有数据操作从 localStorage 改为调用后端 REST API
 */

import { Keyframe, Group, VideoEntry } from './types';

const API_BASE = '/api';

// ── 错误处理 ──────────────────────────────────────────────────────────────
class APIError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = 'APIError';
  }
}

async function handleResponse<T>(response: Response): Promise<T> {
  if (!response.ok) {
    const error = await response.text();
    throw new APIError(response.status, error || `HTTP ${response.status}`);
  }
  return response.json();
}

// ── Video 操作 ────────────────────────────────────────────────────────────

export const videoService = {
  async getAll(): Promise<VideoEntry[]> {
    const response = await fetch(`${API_BASE}/videos`);
    return handleResponse(response);
  },

  async get(id: string): Promise<VideoEntry> {
    const response = await fetch(`${API_BASE}/videos/${id}`);
    return handleResponse(response);
  },

  async create(video: Omit<VideoEntry, 'id'>): Promise<VideoEntry> {
    const response = await fetch(`${API_BASE}/videos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(video),
    });
    return handleResponse(response);
  },

  async update(id: string, video: Partial<VideoEntry>): Promise<VideoEntry> {
    const response = await fetch(`${API_BASE}/videos/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(video),
    });
    return handleResponse(response);
  },

  async delete(id: string): Promise<void> {
    const response = await fetch(`${API_BASE}/videos/${id}`, {
      method: 'DELETE',
    });
    await handleResponse(response);
  },
};

// ── Keyframe 操作 ──────────────────────────────────────────────────────────

export const keyframeService = {
  async getAll(): Promise<Keyframe[]> {
    const response = await fetch(`${API_BASE}/keyframes`);
    return handleResponse(response);
  },

  async get(id: string): Promise<Keyframe> {
    const response = await fetch(`${API_BASE}/keyframes/${id}`);
    return handleResponse(response);
  },

  async create(keyframe: Omit<Keyframe, 'id'>): Promise<Keyframe> {
    const response = await fetch(`${API_BASE}/keyframes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...keyframe,
        videoId: keyframe.videoId,
        groupId: keyframe.groupId,
        createdAt: keyframe.createdAt,
      }),
    });
    return handleResponse(response);
  },

  async update(id: string, keyframe: Partial<Keyframe>): Promise<Keyframe> {
    const response = await fetch(`${API_BASE}/keyframes/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(keyframe),
    });
    return handleResponse(response);
  },

  async delete(id: string): Promise<void> {
    const response = await fetch(`${API_BASE}/keyframes/${id}`, {
      method: 'DELETE',
    });
    await handleResponse(response);
  },
};

// ── Group 操作 ─────────────────────────────────────────────────────────────

export const groupService = {
  async getAll(): Promise<Group[]> {
    const response = await fetch(`${API_BASE}/groups`);
    return handleResponse(response);
  },

  async get(id: string): Promise<Group> {
    const response = await fetch(`${API_BASE}/groups/${id}`);
    return handleResponse(response);
  },

  async create(group: Omit<Group, 'id'>): Promise<Group> {
    const response = await fetch(`${API_BASE}/groups`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(group),
    });
    return handleResponse(response);
  },

  async update(id: string, group: Partial<Group>): Promise<Group> {
    const response = await fetch(`${API_BASE}/groups/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(group),
    });
    return handleResponse(response);
  },

  async delete(id: string): Promise<void> {
    const response = await fetch(`${API_BASE}/groups/${id}`, {
      method: 'DELETE',
    });
    await handleResponse(response);
  },
};

// ── AppState 操作 ──────────────────────────────────────────────────────────

export const appStateService = {
  async get() {
    const response = await fetch(`${API_BASE}/app-state`);
    return handleResponse(response);
  },

  async update(state: any) {
    const response = await fetch(`${API_BASE}/app-state`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(state),
    });
    return handleResponse(response);
  },
};

// ── 数据备份/恢复 ──────────────────────────────────────────────────────────

export const backupService = {
  async exportAll() {
    const response = await fetch(`${API_BASE}/backup/all`);
    return handleResponse(response);
  },

  async importAll(data: any) {
    const response = await fetch(`${API_BASE}/backup/restore`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    return handleResponse(response);
  },

  async clear() {
    const response = await fetch(`${API_BASE}/backup/clear`, {
      method: 'DELETE',
    });
    return handleResponse(response);
  },
};

// ── 统计接口 ────────────────────────────────────────────────────────────

export const statsService = {
  async get() {
    const response = await fetch(`${API_BASE}/stats`);
    return handleResponse(response);
  },
};

// ── 兼容层：保持原有 API 接口 ──────────────────────────────────────────────

export const storageService = {
  // Videos
  getVideos: () => videoService.getAll(),
  saveVideos: async (videos: VideoEntry[]) => {
    // 这个方法在新架构中不再使用，因为每个视频单独保存
  },
  
  // Keyframes
  getKeyframes: () => keyframeService.getAll(),
  saveKeyframes: async (keyframes: Keyframe[]) => {
    // 这个方法在新架构中不再使用，因为每个关键帧单独保存
  },
  
  // Libraries (Groups)
  getLibraries: () => groupService.getAll(),
  saveLibraries: async (groups: Group[]) => {
    // 这个方法在新架构中不再使用，因为每个分组单独保存
  },
  
  // AppState
  getAppState: () => appStateService.get(),
  saveAppState: (state: any) => appStateService.update(state),
  
  // Backup/Restore
  exportBackup: () => backupService.exportAll(),
  importBackup: (data: any) => backupService.importAll(data),
  clearAllData: () => backupService.clear(),
};
