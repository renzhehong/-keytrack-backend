/**
 * 自定义 Hook：从后端 API 加载应用数据
 * 处理所有数据的初始化和同步
 */

import { useState, useEffect } from 'react';
import { Keyframe, Group, VideoEntry } from './types';
import { videoService, keyframeService, groupService, appStateService } from './storageService';

export interface AppData {
  videos: VideoEntry[];
  keyframes: Keyframe[];
  groups: Group[];
  currentVideoId: string | null;
  sidebarOpen: boolean;
  theaterMode: boolean;
  playbackSpeed: number;
  videoZoom: number;
  loading: boolean;
  error: string | null;
}

export function useAppData() {
  const [data, setData] = useState<AppData>({
    videos: [],
    keyframes: [],
    groups: [],
    currentVideoId: null,
    sidebarOpen: true,
    theaterMode: false,
    playbackSpeed: 1,
    videoZoom: 1,
    loading: true,
    error: null,
  });

  // 初始化加载数据
  useEffect(() => {
    const loadData = async () => {
      try {
        setData(prev => ({ ...prev, loading: true, error: null }));
        
        const [videos, keyframes, groups, appState] = await Promise.all([
          videoService.getAll(),
          keyframeService.getAll(),
          groupService.getAll(),
          appStateService.get(),
        ]);

        // 如果没有默认分组，创建一个
        if (groups.length === 0) {
          const defaultGroup = await groupService.create({
            name: 'General Archive',
            color: '#D4AF37',
          });
          groups.push(defaultGroup);
        }

        setData({
          videos,
          keyframes,
          groups,
          currentVideoId: appState.current_video_id || null,
          sidebarOpen: Boolean(appState.sidebar_open),
          theaterMode: Boolean(appState.theater_mode),
          playbackSpeed: appState.playback_speed,
          videoZoom: appState.video_zoom,
          loading: false,
          error: null,
        });
      } catch (err) {
        console.error('Failed to load data:', err);
        setData(prev => ({
          ...prev,
          loading: false,
          error: err instanceof Error ? err.message : 'Failed to load data',
        }));
      }
    };

    loadData();
  }, []);

  // 保存应用状态
  const saveAppState = async (updates: Partial<AppData>) => {
    try {
      await appStateService.update({
        current_video_id: updates.currentVideoId ?? data.currentVideoId,
        sidebar_open: updates.sidebarOpen ?? data.sidebarOpen ? 1 : 0,
        theater_mode: updates.theaterMode ?? data.theaterMode ? 1 : 0,
        playback_speed: updates.playbackSpeed ?? data.playbackSpeed,
        video_zoom: updates.videoZoom ?? data.videoZoom,
      });

      setData(prev => ({ ...prev, ...updates }));
    } catch (err) {
      console.error('Failed to save app state:', err);
    }
  };

  // Video 操作
  const addVideo = async (video: Omit<VideoEntry, 'id'>) => {
    try {
      const newVideo = await videoService.create(video);
      setData(prev => ({
        ...prev,
        videos: [newVideo, ...prev.videos],
      }));
      return newVideo;
    } catch (err) {
      console.error('Failed to add video:', err);
      throw err;
    }
  };

  const updateVideo = async (id: string, updates: Partial<VideoEntry>) => {
    try {
      const updated = await videoService.update(id, updates);
      setData(prev => ({
        ...prev,
        videos: prev.videos.map(v => v.id === id ? updated : v),
      }));
      return updated;
    } catch (err) {
      console.error('Failed to update video:', err);
      throw err;
    }
  };

  const deleteVideo = async (id: string) => {
    try {
      await videoService.delete(id);
      setData(prev => ({
        ...prev,
        videos: prev.videos.filter(v => v.id !== id),
        keyframes: prev.keyframes.filter(kf => kf.videoId !== id),
        currentVideoId: prev.currentVideoId === id ? null : prev.currentVideoId,
      }));
    } catch (err) {
      console.error('Failed to delete video:', err);
      throw err;
    }
  };

  // Keyframe 操作
  const addKeyframe = async (keyframe: Omit<Keyframe, 'id'>) => {
    try {
      const newKeyframe = await keyframeService.create(keyframe);
      setData(prev => ({
        ...prev,
        keyframes: [...prev.keyframes, newKeyframe],
      }));
      return newKeyframe;
    } catch (err) {
      console.error('Failed to add keyframe:', err);
      throw err;
    }
  };

  const updateKeyframe = async (id: string, updates: Partial<Keyframe>) => {
    try {
      const updated = await keyframeService.update(id, updates);
      setData(prev => ({
        ...prev,
        keyframes: prev.keyframes.map(kf => kf.id === id ? updated : kf),
      }));
      return updated;
    } catch (err) {
      console.error('Failed to update keyframe:', err);
      throw err;
    }
  };

  const deleteKeyframe = async (id: string) => {
    try {
      await keyframeService.delete(id);
      setData(prev => ({
        ...prev,
        keyframes: prev.keyframes.filter(kf => kf.id !== id),
      }));
    } catch (err) {
      console.error('Failed to delete keyframe:', err);
      throw err;
    }
  };

  // Group 操作
  const addGroup = async (group: Omit<Group, 'id'>) => {
    try {
      const newGroup = await groupService.create(group);
      setData(prev => ({
        ...prev,
        groups: [...prev.groups, newGroup],
      }));
      return newGroup;
    } catch (err) {
      console.error('Failed to add group:', err);
      throw err;
    }
  };

  const updateGroup = async (id: string, updates: Partial<Group>) => {
    try {
      const updated = await groupService.update(id, updates);
      setData(prev => ({
        ...prev,
        groups: prev.groups.map(g => g.id === id ? updated : g),
      }));
      return updated;
    } catch (err) {
      console.error('Failed to update group:', err);
      throw err;
    }
  };

  const deleteGroup = async (id: string) => {
    try {
      await groupService.delete(id);
      setData(prev => ({
        ...prev,
        groups: prev.groups.filter(g => g.id !== id),
      }));
    } catch (err) {
      console.error('Failed to delete group:', err);
      throw err;
    }
  };

  return {
    data,
    saveAppState,
    addVideo,
    updateVideo,
    deleteVideo,
    addKeyframe,
    updateKeyframe,
    deleteKeyframe,
    addGroup,
    updateGroup,
    deleteGroup,
  };
}
