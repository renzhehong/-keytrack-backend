# KeyTrack 一键启动脚本
# 同时启动后端和前端服务

Write-Host "================================" -ForegroundColor Cyan
Write-Host "KeyTrack 启动脚本" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan

# 获取脚本所在目录
$scriptPath = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
$projectRoot = $scriptPath

Write-Host ""
Write-Host "项目路径: $projectRoot" -ForegroundColor Green

# 检查必要文件
$backendDir = Join-Path $projectRoot "backend"
$frontendDir = $projectRoot

if (-not (Test-Path $backendDir)) {
    Write-Host "错误: 找不到 backend 目录" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "1. 启动后端服务..." -ForegroundColor Yellow

# 启动后端（新窗口）
$backendCmd = "cd '$backendDir'; `$env:PYTHONUNBUFFERED=1; python -m uvicorn main:app --host 0.0.0.0 --port 8000; Read-Host 'Press Enter to close'"
Start-Process PowerShell -ArgumentList "-NoExit", "-Command", $backendCmd -WindowStyle Normal

# 等待后端启动
Write-Host "等待后端启动..." -ForegroundColor Cyan
Start-Sleep -Seconds 3

# 检查后端是否运行
$maxRetries = 5
$retryCount = 0
$backendReady = $false

while ($retryCount -lt $maxRetries) {
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:8000/api/health" -ErrorAction Stop
        if ($response.StatusCode -eq 200) {
            $backendReady = $true
            Write-Host "✓ 后端已启动" -ForegroundColor Green
            break
        }
    } catch {
        $retryCount++
        if ($retryCount -lt $maxRetries) {
            Write-Host "等待后端启动... ($retryCount/$maxRetries)" -ForegroundColor Gray
            Start-Sleep -Seconds 2
        }
    }
}

if (-not $backendReady) {
    Write-Host "警告: 后端启动可能失败，请检查后端窗口的错误信息" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "2. 启动前端服务..." -ForegroundColor Yellow

# 启动前端（新窗口）
$frontendCmd = "cd '$frontendDir'; `$env:PYTHONUNBUFFERED=1; Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass; npm run dev; Read-Host 'Press Enter to close'"
Start-Process PowerShell -ArgumentList "-NoExit", "-Command", $frontendCmd -WindowStyle Normal

# 等待前端启动
Write-Host "等待前端启动..." -ForegroundColor Cyan
Start-Sleep -Seconds 5

Write-Host ""
Write-Host "================================" -ForegroundColor Green
Write-Host "启动完成！" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Green
Write-Host ""
Write-Host "后端 API: http://localhost:8000" -ForegroundColor Cyan
Write-Host "前端应用: http://localhost:3000" -ForegroundColor Cyan
Write-Host "API 文档: http://localhost:8000/docs" -ForegroundColor Cyan
Write-Host ""
Write-Host "提示: 两个服务窗口都在运行，请勿关闭。" -ForegroundColor Yellow
Write-Host ""

# 打开浏览器
Start-Sleep -Seconds 2
Write-Host "正在打开浏览器..." -ForegroundColor Cyan
Start-Process "http://localhost:3000"

Write-Host ""
Write-Host "按 Ctrl+C 停止此脚本（后端和前端窗口将继续运行）" -ForegroundColor Yellow
Read-Host "按 Enter 键退出"
