# KeyTrack 快速开始指南

## 5 分钟快速上手

### 步骤 1：解压项目

```bash
unzip keytrack-with-backend.zip
cd keytrack-with-backend
```

### 步骤 2：一键启动

#### Windows PowerShell
```powershell
.\start.ps1
```

#### macOS/Linux
```bash
bash start.sh
```

脚本会自动：
- ✓ 启动后端服务（http://localhost:8000）
- ✓ 启动前端应用（http://localhost:3000）
- ✓ 打开浏览器

### 步骤 3：开始使用

1. **上传视频**：点击 "Add Video" 按钮
2. **标记关键帧**：在视频中点击时间轴标记重要时刻
3. **添加笔记**：为每个关键帧添加说明
4. **分组管理**：创建标签库组织关键帧

---

## 如果一键启动失败

### 手动启动后端

```bash
# Windows (CMD)
cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8000

# macOS/Linux
cd backend
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000
```

### 手动启动前端（新终端）

```bash
npm install
npm run dev
```

### 打开浏览器

访问 `http://localhost:3000`

---

## 数据保存

所有数据自动保存到 `backend/data/keytrack.db`：
- ✓ 视频列表
- ✓ 关键帧标记
- ✓ 笔记内容
- ✓ 标签分组

**关闭应用不会丢失数据**，重新启动后数据仍然存在。

---

## 备份数据

### 导出备份
```bash
curl http://localhost:8000/api/backup/all > backup.json
```

### 导入备份
```bash
curl -X POST http://localhost:8000/api/backup/restore \
  -H "Content-Type: application/json" \
  -d @backup.json
```

---

## 常见问题

| 问题 | 解决方案 |
|------|--------|
| 后端启动失败 | 检查 Python 3.10+ 是否安装；运行 `pip install -r backend/requirements.txt` |
| 前端无法连接后端 | 确保后端运行在 8000 端口；访问 `http://localhost:8000/api/health` 测试 |
| 端口被占用 | 修改 `vite.config.ts` 和后端启动命令中的端口号 |
| 数据丢失 | 从 `backup.json` 恢复；或访问 `http://localhost:8000/docs` 查看 API 文档 |

---

## 下一步

- 📖 详细文档：查看 `BACKEND_DEPLOYMENT.md`
- 🔌 API 文档：访问 `http://localhost:8000/docs`
- 🌐 部署到云端：参考部署指南中的生产部署章节
- ☁️ 云盘同步：配置 Google Drive/OneDrive 自动备份

---

**需要帮助？** 检查 `backend/server.log` 查看错误信息。
