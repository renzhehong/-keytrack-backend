"""
Pydantic Schema 定义，用于 API 请求/响应验证
"""

from pydantic import BaseModel
from typing import Optional, List


# ── Video Schemas ──────────────────────────────────────────────────────────
class VideoEntryCreate(BaseModel):
    title: str
    url: str
    type: str = "url"  # 'file' 或 'url'
    last_accessed: int


class VideoEntryUpdate(BaseModel):
    title: Optional[str] = None
    url: Optional[str] = None
    last_accessed: Optional[int] = None


class VideoEntryResponse(BaseModel):
    id: str
    title: str
    url: str
    type: str
    last_accessed: int

    class Config:
        from_attributes = True


# ── Keyframe Schemas ───────────────────────────────────────────────────────
class KeyframeCreate(BaseModel):
    video_id: str
    time: float
    note: Optional[str] = None
    group_id: str
    created_at: int


class KeyframeUpdate(BaseModel):
    time: Optional[float] = None
    note: Optional[str] = None
    group_id: Optional[str] = None


class KeyframeResponse(BaseModel):
    id: str
    video_id: str
    time: float
    note: Optional[str]
    group_id: str
    created_at: int

    class Config:
        from_attributes = True


# ── Group Schemas ──────────────────────────────────────────────────────────
class GroupCreate(BaseModel):
    name: str
    color: str


class GroupUpdate(BaseModel):
    name: Optional[str] = None
    color: Optional[str] = None


class GroupResponse(BaseModel):
    id: str
    name: str
    color: str

    class Config:
        from_attributes = True


# ── AppState Schemas ───────────────────────────────────────────────────────
class AppStateUpdate(BaseModel):
    current_video_id: Optional[str] = None
    sidebar_open: Optional[int] = None
    theater_mode: Optional[int] = None
    playback_speed: Optional[float] = None
    video_zoom: Optional[float] = None


class AppStateResponse(BaseModel):
    id: int
    current_video_id: Optional[str]
    sidebar_open: int
    theater_mode: int
    playback_speed: float
    video_zoom: float

    class Config:
        from_attributes = True


# ── Bulk Data Schemas ──────────────────────────────────────────────────────
class BulkDataRequest(BaseModel):
    """用于导入/导出整个应用数据"""
    videos: List[VideoEntryResponse]
    keyframes: List[KeyframeResponse]
    groups: List[GroupResponse]
    app_state: AppStateResponse


class HealthResponse(BaseModel):
    status: str
    message: str
