"""
KeyTrack 后端数据库模型
使用 SQLAlchemy ORM，对应前端的 types.ts 数据结构
"""

from sqlalchemy import Column, String, Integer, Float, Text, JSON, create_engine
from sqlalchemy.orm import declarative_base, sessionmaker
from pathlib import Path
import os

# ── 数据库初始化 ──────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
DB_PATH = DATA_DIR / "keytrack.db"

# 创建目录
DATA_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(exist_ok=True)

DATABASE_URL = f"sqlite:///{DB_PATH}"
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False,
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


# ── 数据库表定义 ──────────────────────────────────────────────────────────────

class VideoEntry(Base):
    """
    对应前端 VideoEntry 接口。
    视频条目：id、标题、URL、类型（本地文件或 URL）、最后访问时间
    """
    __tablename__ = "videos"

    id = Column(String, primary_key=True, index=True)
    title = Column(String, nullable=False)
    url = Column(String, nullable=False)
    type = Column(String, default="url")  # 'file' 或 'url'
    last_accessed = Column(Integer, nullable=False)  # Unix 时间戳 (ms)


class Keyframe(Base):
    """
    对应前端 Keyframe 接口。
    关键帧：在视频中标记的特定时间点，包含笔记和分组信息
    """
    __tablename__ = "keyframes"

    id = Column(String, primary_key=True, index=True)
    video_id = Column(String, nullable=False, index=True)
    time = Column(Float, nullable=False)  # 秒数
    note = Column(Text, nullable=True)
    group_id = Column(String, nullable=False)
    created_at = Column(Integer, nullable=False)  # Unix 时间戳 (ms)


class Group(Base):
    """
    对应前端 Group 接口。
    标签分组：用于组织和分类关键帧
    """
    __tablename__ = "groups"

    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    color = Column(String, nullable=False)  # 十六进制颜色代码


class AppState(Base):
    """
    全局应用状态（单例，id 固定为 1）。
    存储当前选中的视频、侧边栏状态等全局配置。
    """
    __tablename__ = "app_state"

    id = Column(Integer, primary_key=True, default=1)
    current_video_id = Column(String, nullable=True)
    sidebar_open = Column(Integer, default=1)  # 1=true, 0=false
    theater_mode = Column(Integer, default=0)
    playback_speed = Column(Float, default=1.0)
    video_zoom = Column(Float, default=1.0)


def create_tables():
    """创建所有数据库表（如果不存在）"""
    Base.metadata.create_all(bind=engine)


def get_db():
    """FastAPI 依赖注入：获取数据库 Session"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
