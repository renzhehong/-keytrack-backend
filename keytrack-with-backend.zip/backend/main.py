"""
KeyTrack 后端 FastAPI 应用
提供视频、关键帧、标签分组的 REST API
"""

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import delete
import json
from typing import List

from models import (
    create_tables, get_db, VideoEntry, Keyframe, Group, AppState,
    DB_PATH, DATA_DIR
)
from schemas import (
    VideoEntryCreate, VideoEntryResponse, VideoEntryUpdate,
    KeyframeCreate, KeyframeResponse, KeyframeUpdate,
    GroupCreate, GroupResponse, GroupUpdate,
    AppStateUpdate, AppStateResponse,
    BulkDataRequest, HealthResponse
)

# ── 应用初始化 ──────────────────────────────────────────────────────────────
app = FastAPI(title="KeyTrack API", version="1.0.0")

# CORS 配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 启动事件
@app.on_event("startup")
def startup_event():
    create_tables()
    print(f"[OK] Database initialized: {DB_PATH}")
    print(f"[OK] Data directory: {DATA_DIR}")


# ── 健康检查 ──────────────────────────────────────────────────────────────
@app.get("/api/health", response_model=HealthResponse)
def health_check():
    return HealthResponse(status="healthy", message="KeyTrack API is running")


# ── Video 接口 ────────────────────────────────────────────────────────────

@app.get("/api/videos", response_model=List[VideoEntryResponse])
def list_videos(db: Session = Depends(get_db)):
    """获取所有视频"""
    videos = db.query(VideoEntry).all()
    return videos


@app.post("/api/videos", response_model=VideoEntryResponse)
def create_video(video: VideoEntryCreate, db: Session = Depends(get_db)):
    """创建新视频"""
    import uuid
    db_video = VideoEntry(id=str(uuid.uuid4()), **video.dict())
    db.add(db_video)
    db.commit()
    db.refresh(db_video)
    return db_video


@app.get("/api/videos/{video_id}", response_model=VideoEntryResponse)
def get_video(video_id: str, db: Session = Depends(get_db)):
    """获取单个视频"""
    video = db.query(VideoEntry).filter(VideoEntry.id == video_id).first()
    if not video:
        raise HTTPException(status_code=404, detail="Video not found")
    return video


@app.put("/api/videos/{video_id}", response_model=VideoEntryResponse)
def update_video(video_id: str, video: VideoEntryUpdate, db: Session = Depends(get_db)):
    """更新视频"""
    db_video = db.query(VideoEntry).filter(VideoEntry.id == video_id).first()
    if not db_video:
        raise HTTPException(status_code=404, detail="Video not found")
    
    for key, value in video.dict(exclude_unset=True).items():
        setattr(db_video, key, value)
    
    db.commit()
    db.refresh(db_video)
    return db_video


@app.delete("/api/videos/{video_id}")
def delete_video(video_id: str, db: Session = Depends(get_db)):
    """删除视频及其关键帧"""
    db_video = db.query(VideoEntry).filter(VideoEntry.id == video_id).first()
    if not db_video:
        raise HTTPException(status_code=404, detail="Video not found")
    
    # 删除关联的关键帧
    db.query(Keyframe).filter(Keyframe.video_id == video_id).delete()
    db.delete(db_video)
    db.commit()
    return {"message": "Video deleted"}


# ── Keyframe 接口 ──────────────────────────────────────────────────────────

@app.get("/api/keyframes", response_model=List[KeyframeResponse])
def list_keyframes(db: Session = Depends(get_db)):
    """获取所有关键帧"""
    keyframes = db.query(Keyframe).all()
    return keyframes


@app.post("/api/keyframes", response_model=KeyframeResponse)
def create_keyframe(keyframe: KeyframeCreate, db: Session = Depends(get_db)):
    """创建新关键帧"""
    import uuid
    db_keyframe = Keyframe(id=str(uuid.uuid4()), **keyframe.dict())
    db.add(db_keyframe)
    db.commit()
    db.refresh(db_keyframe)
    return db_keyframe


@app.get("/api/keyframes/{keyframe_id}", response_model=KeyframeResponse)
def get_keyframe(keyframe_id: str, db: Session = Depends(get_db)):
    """获取单个关键帧"""
    keyframe = db.query(Keyframe).filter(Keyframe.id == keyframe_id).first()
    if not keyframe:
        raise HTTPException(status_code=404, detail="Keyframe not found")
    return keyframe


@app.put("/api/keyframes/{keyframe_id}", response_model=KeyframeResponse)
def update_keyframe(keyframe_id: str, keyframe: KeyframeUpdate, db: Session = Depends(get_db)):
    """更新关键帧"""
    db_keyframe = db.query(Keyframe).filter(Keyframe.id == keyframe_id).first()
    if not db_keyframe:
        raise HTTPException(status_code=404, detail="Keyframe not found")
    
    for key, value in keyframe.dict(exclude_unset=True).items():
        setattr(db_keyframe, key, value)
    
    db.commit()
    db.refresh(db_keyframe)
    return db_keyframe


@app.delete("/api/keyframes/{keyframe_id}")
def delete_keyframe(keyframe_id: str, db: Session = Depends(get_db)):
    """删除关键帧"""
    db_keyframe = db.query(Keyframe).filter(Keyframe.id == keyframe_id).first()
    if not db_keyframe:
        raise HTTPException(status_code=404, detail="Keyframe not found")
    
    db.delete(db_keyframe)
    db.commit()
    return {"message": "Keyframe deleted"}


# ── Group 接口 ─────────────────────────────────────────────────────────────

@app.get("/api/groups", response_model=List[GroupResponse])
def list_groups(db: Session = Depends(get_db)):
    """获取所有标签分组"""
    groups = db.query(Group).all()
    return groups


@app.post("/api/groups", response_model=GroupResponse)
def create_group(group: GroupCreate, db: Session = Depends(get_db)):
    """创建新标签分组"""
    import uuid
    db_group = Group(id=str(uuid.uuid4()), **group.dict())
    db.add(db_group)
    db.commit()
    db.refresh(db_group)
    return db_group


@app.get("/api/groups/{group_id}", response_model=GroupResponse)
def get_group(group_id: str, db: Session = Depends(get_db)):
    """获取单个标签分组"""
    group = db.query(Group).filter(Group.id == group_id).first()
    if not group:
        raise HTTPException(status_code=404, detail="Group not found")
    return group


@app.put("/api/groups/{group_id}", response_model=GroupResponse)
def update_group(group_id: str, group: GroupUpdate, db: Session = Depends(get_db)):
    """更新标签分组"""
    db_group = db.query(Group).filter(Group.id == group_id).first()
    if not db_group:
        raise HTTPException(status_code=404, detail="Group not found")
    
    for key, value in group.dict(exclude_unset=True).items():
        setattr(db_group, key, value)
    
    db.commit()
    db.refresh(db_group)
    return db_group


@app.delete("/api/groups/{group_id}")
def delete_group(group_id: str, db: Session = Depends(get_db)):
    """删除标签分组"""
    db_group = db.query(Group).filter(Group.id == group_id).first()
    if not db_group:
        raise HTTPException(status_code=404, detail="Group not found")
    
    db.delete(db_group)
    db.commit()
    return {"message": "Group deleted"}


# ── AppState 接口 ──────────────────────────────────────────────────────────

@app.get("/api/app-state", response_model=AppStateResponse)
def get_app_state(db: Session = Depends(get_db)):
    """获取应用全局状态"""
    state = db.query(AppState).filter(AppState.id == 1).first()
    if not state:
        # 创建默认状态
        state = AppState(id=1)
        db.add(state)
        db.commit()
        db.refresh(state)
    return state


@app.put("/api/app-state", response_model=AppStateResponse)
def update_app_state(state_update: AppStateUpdate, db: Session = Depends(get_db)):
    """更新应用全局状态"""
    state = db.query(AppState).filter(AppState.id == 1).first()
    if not state:
        state = AppState(id=1)
        db.add(state)
    
    for key, value in state_update.dict(exclude_unset=True).items():
        setattr(state, key, value)
    
    db.commit()
    db.refresh(state)
    return state


# ── 数据导入/导出 ──────────────────────────────────────────────────────────

@app.get("/api/backup/all")
def backup_all_data(db: Session = Depends(get_db)):
    """导出所有数据为 JSON"""
    videos = db.query(VideoEntry).all()
    keyframes = db.query(Keyframe).all()
    groups = db.query(Group).all()
    app_state = db.query(AppState).filter(AppState.id == 1).first()
    
    if not app_state:
        app_state = AppState(id=1)
    
    data = {
        "videos": [
            {
                "id": v.id,
                "title": v.title,
                "url": v.url,
                "type": v.type,
                "lastAccessed": v.last_accessed
            }
            for v in videos
        ],
        "keyframes": [
            {
                "id": k.id,
                "videoId": k.video_id,
                "time": k.time,
                "note": k.note,
                "groupId": k.group_id,
                "createdAt": k.created_at
            }
            for k in keyframes
        ],
        "libraries": [
            {
                "id": g.id,
                "name": g.name,
                "color": g.color
            }
            for g in groups
        ],
        "appState": {
            "currentVideoId": app_state.current_video_id,
            "sidebarOpen": bool(app_state.sidebar_open),
            "theaterMode": bool(app_state.theater_mode),
            "playbackSpeed": app_state.playback_speed,
            "videoZoom": app_state.video_zoom
        }
    }
    
    return data


@app.post("/api/backup/restore")
def restore_all_data(data: BulkDataRequest, db: Session = Depends(get_db)):
    """导入所有数据"""
    try:
        # 清空现有数据
        db.query(Keyframe).delete()
        db.query(VideoEntry).delete()
        db.query(Group).delete()
        db.query(AppState).delete()
        
        # 导入视频
        for video in data.videos:
            db_video = VideoEntry(
                id=video.id,
                title=video.title,
                url=video.url,
                type=video.type,
                last_accessed=video.last_accessed
            )
            db.add(db_video)
        
        # 导入标签分组
        for group in data.groups:
            db_group = Group(
                id=group.id,
                name=group.name,
                color=group.color
            )
            db.add(db_group)
        
        # 导入关键帧
        for keyframe in data.keyframes:
            db_keyframe = Keyframe(
                id=keyframe.id,
                video_id=keyframe.video_id,
                time=keyframe.time,
                note=keyframe.note,
                group_id=keyframe.group_id,
                created_at=keyframe.created_at
            )
            db.add(db_keyframe)
        
        # 导入应用状态
        app_state = AppState(
            id=1,
            current_video_id=data.app_state.current_video_id,
            sidebar_open=data.app_state.sidebar_open,
            theater_mode=data.app_state.theater_mode,
            playback_speed=data.app_state.playback_speed,
            video_zoom=data.app_state.video_zoom
        )
        db.add(app_state)
        
        db.commit()
        return {"message": "Data restored successfully"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=str(e))


@app.delete("/api/backup/clear")
def clear_all_data(db: Session = Depends(get_db)):
    """清空所有数据"""
    db.query(Keyframe).delete()
    db.query(VideoEntry).delete()
    db.query(Group).delete()
    db.query(AppState).delete()
    db.commit()
    return {"message": "All data cleared"}


# ── 统计接口 ────────────────────────────────────────────────────────────

@app.get("/api/stats")
def get_stats(db: Session = Depends(get_db)):
    """获取数据统计"""
    video_count = db.query(VideoEntry).count()
    keyframe_count = db.query(Keyframe).count()
    group_count = db.query(Group).count()
    
    return {
        "videos": video_count,
        "keyframes": keyframe_count,
        "groups": group_count,
        "database": str(DB_PATH),
        "database_size_mb": DB_PATH.stat().st_size / (1024 * 1024) if DB_PATH.exists() else 0
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
