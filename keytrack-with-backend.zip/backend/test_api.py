#!/usr/bin/env python3
"""
KeyTrack 后端 API 测试脚本
"""

import requests
import json
import time

BASE_URL = "http://localhost:8000/api"

def test_health():
    """测试健康检查"""
    print("\n=== 测试健康检查 ===")
    response = requests.get(f"{BASE_URL}/health")
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    assert response.status_code == 200

def test_groups():
    """测试标签分组 API"""
    print("\n=== 测试标签分组 ===")
    
    # 创建分组
    print("1. 创建分组...")
    group_data = {"name": "Important", "color": "#ff0000"}
    response = requests.post(f"{BASE_URL}/groups", json=group_data)
    print(f"Status: {response.status_code}")
    group = response.json()
    print(f"创建的分组: {group}")
    group_id = group["id"]
    assert response.status_code == 200
    
    # 获取所有分组
    print("2. 获取所有分组...")
    response = requests.get(f"{BASE_URL}/groups")
    groups = response.json()
    print(f"分组列表: {json.dumps(groups, indent=2)}")
    assert len(groups) > 0
    
    # 获取单个分组
    print(f"3. 获取分组 {group_id}...")
    response = requests.get(f"{BASE_URL}/groups/{group_id}")
    group = response.json()
    print(f"分组详情: {group}")
    assert response.status_code == 200
    
    # 更新分组
    print("4. 更新分组...")
    update_data = {"name": "Very Important", "color": "#00ff00"}
    response = requests.put(f"{BASE_URL}/groups/{group_id}", json=update_data)
    group = response.json()
    print(f"更新后的分组: {group}")
    assert response.status_code == 200
    
    return group_id

def test_videos(group_id):
    """测试视频 API"""
    print("\n=== 测试视频 ===")
    
    # 创建视频
    print("1. 创建视频...")
    video_data = {
        "title": "Test Video",
        "url": "https://example.com/video.mp4",
        "type": "url",
        "last_accessed": int(time.time() * 1000)
    }
    response = requests.post(f"{BASE_URL}/videos", json=video_data)
    print(f"Status: {response.status_code}")
    video = response.json()
    print(f"创建的视频: {video}")
    video_id = video["id"]
    assert response.status_code == 200
    
    # 获取所有视频
    print("2. 获取所有视频...")
    response = requests.get(f"{BASE_URL}/videos")
    videos = response.json()
    print(f"视频列表: {json.dumps(videos, indent=2)}")
    assert len(videos) > 0
    
    # 获取单个视频
    print(f"3. 获取视频 {video_id}...")
    response = requests.get(f"{BASE_URL}/videos/{video_id}")
    video = response.json()
    print(f"视频详情: {video}")
    assert response.status_code == 200
    
    # 更新视频
    print("4. 更新视频...")
    update_data = {"title": "Updated Video Title"}
    response = requests.put(f"{BASE_URL}/videos/{video_id}", json=update_data)
    video = response.json()
    print(f"更新后的视频: {video}")
    assert response.status_code == 200
    
    return video_id

def test_keyframes(video_id, group_id):
    """测试关键帧 API"""
    print("\n=== 测试关键帧 ===")
    
    # 创建关键帧
    print("1. 创建关键帧...")
    keyframe_data = {
        "video_id": video_id,
        "time": 10.5,
        "note": "Important moment",
        "group_id": group_id,
        "created_at": int(time.time() * 1000)
    }
    response = requests.post(f"{BASE_URL}/keyframes", json=keyframe_data)
    print(f"Status: {response.status_code}")
    keyframe = response.json()
    print(f"创建的关键帧: {keyframe}")
    keyframe_id = keyframe["id"]
    assert response.status_code == 200
    
    # 获取所有关键帧
    print("2. 获取所有关键帧...")
    response = requests.get(f"{BASE_URL}/keyframes")
    keyframes = response.json()
    print(f"关键帧列表: {json.dumps(keyframes, indent=2)}")
    assert len(keyframes) > 0
    
    # 获取单个关键帧
    print(f"3. 获取关键帧 {keyframe_id}...")
    response = requests.get(f"{BASE_URL}/keyframes/{keyframe_id}")
    keyframe = response.json()
    print(f"关键帧详情: {keyframe}")
    assert response.status_code == 200
    
    # 更新关键帧
    print("4. 更新关键帧...")
    update_data = {"note": "Updated note", "time": 15.0}
    response = requests.put(f"{BASE_URL}/keyframes/{keyframe_id}", json=update_data)
    keyframe = response.json()
    print(f"更新后的关键帧: {keyframe}")
    assert response.status_code == 200
    
    return keyframe_id

def test_app_state():
    """测试应用状态 API"""
    print("\n=== 测试应用状态 ===")
    
    # 获取应用状态
    print("1. 获取应用状态...")
    response = requests.get(f"{BASE_URL}/app-state")
    state = response.json()
    print(f"应用状态: {json.dumps(state, indent=2)}")
    assert response.status_code == 200
    
    # 更新应用状态
    print("2. 更新应用状态...")
    update_data = {
        "sidebar_open": 0,
        "theater_mode": 1,
        "playback_speed": 1.5,
        "video_zoom": 1.2
    }
    response = requests.put(f"{BASE_URL}/app-state", json=update_data)
    state = response.json()
    print(f"更新后的应用状态: {json.dumps(state, indent=2)}")
    assert response.status_code == 200

def test_stats():
    """测试统计 API"""
    print("\n=== 测试统计 ===")
    response = requests.get(f"{BASE_URL}/stats")
    stats = response.json()
    print(f"统计数据: {json.dumps(stats, indent=2)}")
    assert response.status_code == 200

def test_backup():
    """测试备份/恢复 API"""
    print("\n=== 测试备份/恢复 ===")
    
    # 导出数据
    print("1. 导出所有数据...")
    response = requests.get(f"{BASE_URL}/backup/all")
    backup_data = response.json()
    print(f"导出的数据包含:")
    print(f"  - 视频数: {len(backup_data.get('videos', []))}")
    print(f"  - 关键帧数: {len(backup_data.get('keyframes', []))}")
    print(f"  - 分组数: {len(backup_data.get('libraries', []))}")
    assert response.status_code == 200

def main():
    """运行所有测试"""
    print("=" * 50)
    print("KeyTrack 后端 API 测试")
    print("=" * 50)
    
    try:
        test_health()
        group_id = test_groups()
        video_id = test_videos(group_id)
        keyframe_id = test_keyframes(video_id, group_id)
        test_app_state()
        test_stats()
        test_backup()
        
        print("\n" + "=" * 50)
        print("所有测试通过！✓")
        print("=" * 50)
    except Exception as e:
        print(f"\n测试失败: {e}")
        import traceback
        traceback.print_exc()
        exit(1)

if __name__ == "__main__":
    main()
